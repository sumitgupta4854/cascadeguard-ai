const services = [
  { id: "api", name: "API Gateway", baseline: { latency: 42, errors: 0.12 } },
  { id: "auth", name: "Auth Service", baseline: { latency: 68, errors: 0.08 } },
  { id: "payment", name: "Payment Service", baseline: { latency: 94, errors: 0.21 } },
  { id: "database", name: "Database", baseline: { latency: 18, errors: 0.04 } },
  { id: "notification", name: "Notification Service", baseline: { latency: 76, errors: 0.16 } },
];

const dashboard = `
  <div class="app-shell">
    <header class="topbar">
      <div class="brand">
        <div class="brand-mark" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none"><path d="M12 3.2 19 6v5.2c0 4.4-2.8 7.6-7 9.6-4.2-2-7-5.2-7-9.6V6l7-2.8Z" stroke="currentColor" stroke-width="1.5"/><path d="m9.1 12 1.9 1.9 4-4.2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </div>
        <div><div class="brand-name">Cascade<span>Guard</span> AI</div><div class="env-label">Reliability operations / demo cluster</div></div>
      </div>
      <div class="top-meta"><span class="mode-pill">SIMULATION MODE</span><span class="clock" id="clock"></span></div>
    </header>

    <section class="intro" aria-labelledby="page-title">
      <div><div class="eyebrow">Incident command / overview</div><h1 id="page-title">Service health &amp; response</h1><p class="intro-copy">A clear view of dependency health, blast radius, and the next best action.</p></div>
      <div class="actions">
        <button class="button primary" id="simulate"><svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M6 3.4 12 8l-6 4.6V3.4Z" fill="currentColor"/></svg>Simulate failure</button>
        <button class="button" id="reset"><svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3.3 6A5 5 0 1 1 3 9.8M3.2 3.8V6h2.2" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>Reset simulation</button>
        <button class="button" id="report"><svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M4 2.5h5l3 3v8H4v-11Z" stroke="currentColor" stroke-width="1.3"/><path d="M9 2.8v3h2.8M6 9h4M6 11.5h4" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>Generate incident report</button>
      </div>
    </section>

    <section class="incident-banner" id="incident-banner" aria-live="polite">
      <span class="banner-dot"></span><div class="banner-copy"><strong id="banner-title">Cascade event in progress</strong><span id="banner-subtitle"></span></div><span class="banner-time" id="banner-time"></span>
    </section>

    <section class="metrics" aria-label="System summary">
      <article class="metric"><div class="metric-label">Services operational</div><div class="metric-value healthy" id="metric-operational">5 <small>/ 5</small></div><div class="metric-note" id="metric-operational-note">All monitored services nominal</div></article>
      <article class="metric"><div class="metric-label">Overall availability</div><div class="metric-value healthy" id="metric-availability">99.98<small>%</small></div><div class="metric-note">Rolling 5-minute sample window</div></article>
      <article class="metric"><div class="metric-label">Median latency</div><div class="metric-value" id="metric-latency">68 <small>ms</small></div><div class="metric-note" id="metric-latency-note">Across the service graph</div></article>
      <article class="metric"><div class="metric-label">Open incidents</div><div class="metric-value healthy" id="metric-incidents">0</div><div class="metric-note" id="metric-incident-note">No active incident</div></article>
    </section>

    <div class="layout-main">
      <section>
        <section class="panel" aria-labelledby="services-heading">
          <div class="panel-head"><div><h2 class="panel-title" id="services-heading">Service health</h2><div class="panel-kicker">5 critical components · sampled telemetry</div></div><div class="legend"><span class="legend-item"><i class="legend-dot"></i>Healthy</span><span class="legend-item"><i class="legend-dot warn"></i>Degraded</span><span class="legend-item"><i class="legend-dot down"></i>Down</span></div></div>
          <div class="service-list" id="service-list"></div>
        </section>
        <section class="panel graph-panel" aria-labelledby="graph-heading">
          <div class="panel-head"><div><h2 class="panel-title" id="graph-heading">Dependency map</h2><div class="panel-kicker">Request flow · status propagates downstream</div></div><span class="panel-kicker">5 nodes / 6 edges</span></div>
          <div class="graph-wrap">
            <svg class="graph-svg" viewBox="0 0 720 300" preserveAspectRatio="none" aria-label="API Gateway calls Auth, Payment, and Notification services; all three depend on the Database">
              <path id="edge-api-auth" class="edge" d="M150 150 C205 150 220 58 275 58"/>
              <path id="edge-api-payment" class="edge" d="M150 150 C205 150 220 150 275 150"/>
              <path id="edge-api-notify" class="edge" d="M150 150 C205 150 220 242 275 242"/>
              <path id="edge-auth-db" class="edge" d="M405 58 C480 58 500 150 570 150"/>
              <path id="edge-payment-db" class="edge" d="M405 150 C480 150 500 150 570 150"/>
              <path id="edge-notify-db" class="edge" d="M405 242 C480 242 500 150 570 150"/>
            </svg>
            <div class="graph-nodes">
              <div class="graph-node api" data-node="api"></div><div class="graph-node auth" data-node="auth"></div>
              <div class="graph-node pay" data-node="payment"></div><div class="graph-node db" data-node="database"></div>
              <div class="graph-node notify" data-node="notification"></div>
            </div>
            <div class="graph-caption">Solid line = dependency · dotted line = affected path</div>
          </div>
        </section>
      </section>

      <aside class="right-column" aria-label="Incident analysis and recovery">
        <section class="panel" aria-labelledby="cause-heading">
          <div class="panel-head"><div><h2 class="panel-title" id="cause-heading">Root cause analysis</h2><div class="panel-kicker">Local simulation inference</div></div></div>
          <div class="cause-body" id="cause-body"></div>
        </section>
        <section class="panel" aria-labelledby="recovery-heading">
          <div class="panel-head"><div><h2 class="panel-title" id="recovery-heading">Recovery playbook</h2><div class="panel-kicker">Recommended response sequence</div></div></div>
          <ol class="recovery-list" id="recovery-list"></ol>
        </section>
      </aside>
    </div>

    <div class="lower-grid">
      <section class="panel" aria-labelledby="logs-heading">
        <div class="panel-head"><div><h2 class="panel-title" id="logs-heading">Event stream</h2><div class="panel-kicker">Simulated server logs · newest first</div></div><span class="panel-kicker" id="log-count">4 entries</span></div>
        <div class="log-window" id="log-window" role="log" aria-live="polite"></div>
      </section>
      <section class="panel" aria-labelledby="timeline-heading">
        <div class="panel-head"><div><h2 class="panel-title" id="timeline-heading">Incident timeline</h2><div class="panel-kicker">Timestamped response events</div></div><span class="panel-kicker" id="timeline-state">READY</span></div>
        <div class="timeline" id="timeline" aria-live="polite"></div>
      </section>
    </div>
    <footer class="bottom-note"><span class="disclaimer">Educational simulation using sample data; not a production monitoring system.</span><span>Simulated analysis · no live monitoring or real AI</span></footer>
  </div>

  <div class="modal-backdrop" id="report-modal" role="dialog" aria-modal="true" aria-labelledby="report-title">
    <section class="report-modal"><div class="panel-head"><div><h2 class="panel-title" id="report-title">Incident report</h2><div class="panel-kicker">Generated from current browser-local simulation state</div></div><button class="button" id="close-report" aria-label="Close report">Close</button></div><pre class="report-text" id="report-text"></pre><div class="modal-actions"><button class="button" id="copy-report">Copy report</button><button class="button primary" id="download-report">Download .txt</button></div></section>
  </div>
  <div class="toast" id="toast" role="status" aria-live="polite"></div>
`;

document.querySelector("#app").innerHTML = dashboard;

const state = { stage: 0, startedAt: null, eventTimes: [], logs: [], timer: null, simulationComplete: false };
const baselineLogs = [
  { level: "INFO", msg: "gateway: readiness probe passed · upstreams 4/4 healthy" },
  { level: "INFO", msg: "auth-service: token validation p95 within 100ms SLO" },
  { level: "INFO", msg: "payments: settlement queue depth stable at 12" },
  { level: "INFO", msg: "db-primary: connection pool utilization 34% · replica lag 8ms" },
];
const rootSteps = [
  {
    subtitle: "Database pool pressure detected",
    changes: { database: [286, 3.8, "degraded"] },
    log: ["WARN", "db-primary: pool utilization 94% · acquire wait exceeded 250ms"],
    timeline: ["Pool saturation begins", "Database connection acquisition latency rises; first signal detected."],
  },
  {
    subtitle: "Payment requests backing up",
    changes: { database: [1240, 18.6, "down"], payment: [842, 12.4, "degraded"] },
    log: ["ERROR", "payments: transaction timeout · db acquire wait 1.2s · retries accumulating"],
    timeline: ["Payment path degraded", "Payment Service retries amplify pressure on the saturated database.", "warn"],
  },
  {
    subtitle: "Auth and notification paths impacted",
    changes: { database: [2380, 31.2, "down"], payment: [1560, 28.7, "down"], auth: [614, 7.2, "degraded"], notification: [980, 14.1, "degraded"] },
    log: ["ERROR", "auth + notifications: shared pool wait rising · request failures spreading downstream"],
    timeline: ["Cascade reaches dependent services", "Auth Service and Notification Service exceed latency and error thresholds.", "alert"],
  },
  {
    subtitle: "API Gateway is shedding timed-out requests",
    changes: { database: [3400, 42.8, "down"], payment: [2800, 46.5, "down"], auth: [1820, 24.3, "down"], notification: [2140, 38.1, "down"], api: [2260, 19.6, "degraded"] },
    log: ["CRIT", "gateway: upstream timeout rate 19.6% · circuit breaker engaged for failing dependencies"],
    timeline: ["Gateway circuit breaker engaged", "API Gateway sheds failing requests; broad availability impact confirmed.", "alert"],
  },
];

function fmtTime(date = new Date()) {
  return new Intl.DateTimeFormat(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).format(date);
}
function stamp(date = new Date()) {
  return new Intl.DateTimeFormat(undefined, { year: "numeric", month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).format(date);
}

const $ = (selector) => document.querySelector(selector);
function serviceState(id) {
  if (state.stage === 0) return { ...services.find((s) => s.id === id).baseline, status: "healthy" };
  const current = {};
  for (const step of rootSteps.slice(0, state.stage)) {
    if (step.changes[id]) Object.assign(current, { latency: step.changes[id][0], errors: step.changes[id][1], status: step.changes[id][2] });
  }
  return Object.keys(current).length ? current : { ...services.find((s) => s.id === id).baseline, status: "healthy" };
}
function statusLabel(status) {
  return status === "down" ? "Down" : status === "degraded" ? "Degraded" : "Healthy";
}
function renderServices() {
  const serviceList = $("#service-list");
  serviceList.innerHTML = services.map(({ id, name }) => {
    const data = serviceState(id);
    return `<article class="service-card state-${data.status}">
      <div class="service-top"><span class="status-dot"></span><span class="service-status">${statusLabel(data.status)}</span></div>
      <div class="service-name">${name}</div>
      <div class="service-stats">
        <div><span class="service-stat-label">LATENCY</span><span class="service-stat-value">${data.latency} ms</span></div>
        <div><span class="service-stat-label">ERROR RATE</span><span class="service-stat-value">${data.errors.toFixed(2)}%</span></div>
      </div>
    </article>`;
  }).join("");

  document.querySelectorAll(".graph-node").forEach((node) => {
    const id = node.dataset.node;
    const service = services.find((item) => item.id === id);
    const data = serviceState(id);
    node.className = `graph-node ${id} state-${data.status}`;
    node.innerHTML = `<div class="node-head"><i class="status-dot"></i>${service.name}</div><div class="node-meta">${data.latency} ms · ${data.errors.toFixed(2)}% err</div>`;
  });
  const edgeStates = {
    "edge-api-auth": ["api", "auth"], "edge-api-payment": ["api", "payment"],
    "edge-api-notify": ["api", "notification"], "edge-auth-db": ["auth", "database"],
    "edge-payment-db": ["payment", "database"], "edge-notify-db": ["notification", "database"],
  };
  Object.entries(edgeStates).forEach(([edgeId, endpoints]) => {
    const statuses = endpoints.map((id) => serviceState(id).status);
    const element = $(`#${edgeId}`);
    element.classList.toggle("active", statuses.includes("down"));
    element.classList.toggle("warn", !statuses.includes("down") && statuses.includes("degraded"));
  });
}
function renderSummary() {
  const current = services.map((service) => serviceState(service.id));
  const healthy = current.filter((item) => item.status === "healthy").length;
  const median = current.map((item) => item.latency).sort((a, b) => a - b)[Math.floor(current.length / 2)];
  const availability = state.stage === 0 ? "99.98" : ["", "99.72", "97.84", "88.61", "61.38"][state.stage];
  $("#metric-operational").innerHTML = `${healthy} <small>/ 5</small>`;
  $("#metric-operational").className = `metric-value ${healthy === 5 ? "healthy" : healthy >= 3 ? "warning" : "critical"}`;
  $("#metric-operational-note").textContent = healthy === 5 ? "All monitored services nominal" : `${5 - healthy} component${healthy === 4 ? "" : "s"} degraded or down`;
  $("#metric-availability").innerHTML = `${availability}<small>%</small>`;
  $("#metric-availability").className = `metric-value ${state.stage === 0 ? "healthy" : state.stage < 3 ? "warning" : "critical"}`;
  $("#metric-latency").innerHTML = `${median.toLocaleString()} <small>ms</small>`;
  $("#metric-latency").className = `metric-value ${state.stage > 0 ? state.stage < 3 ? "warning" : "critical" : ""}`;
  $("#metric-latency-note").textContent = state.stage ? "Elevated against the 70ms baseline" : "Across the service graph";
  $("#metric-incidents").textContent = state.stage ? "1" : "0";
  $("#metric-incidents").className = `metric-value ${state.stage ? "critical" : "healthy"}`;
  $("#metric-incident-note").textContent = state.stage ? "Cascade simulation active" : "No active incident";
}
function renderCause() {
  const body = $("#cause-body");
  if (!state.stage) {
    body.innerHTML = `<span class="cause-tag"><i class="legend-dot"></i> No active incident</span>
      <h3 class="cause-title">Waiting for a signal</h3>
      <p class="cause-copy">All five services are within their sample operating range. Start a failure simulation to see how a single dependency issue can ripple through the request graph.</p>
      <div class="impact-strip"><div class="impact-cell"><div class="impact-label">Current blast radius</div><div class="impact-value" style="color:var(--mint)">None</div></div><div class="impact-cell"><div class="impact-label">Analysis source</div><div class="impact-value" style="color:var(--blue)">Local rules</div></div></div>`;
    return;
  }
  const level = state.stage < 2 ? "Early warning" : state.stage < 4 ? "Cascade detected" : "Critical impact";
  body.innerHTML = `<span class="cause-tag"><i class="legend-dot down"></i>${level}</span>
    <h3 class="cause-title">Database connection pool exhaustion</h3>
    <p class="cause-copy">The <strong>db-primary pool saturated at 94%</strong> after a simulated connection leak. Payment retries then increased connection demand, while auth and notifications share the same constrained database path. The gateway is now seeing upstream timeouts.</p>
    <div class="impact-strip"><div class="impact-cell"><div class="impact-label">Likely origin</div><div class="impact-value">db-primary / pool</div></div><div class="impact-cell"><div class="impact-label">Current blast radius</div><div class="impact-value">${state.stage === 1 ? "1 service" : state.stage === 2 ? "2 services" : state.stage === 3 ? "4 services" : "5 services"}</div></div></div>`;
}
function renderRecovery() {
  const items = state.stage === 0
    ? ["Confirm the first failing signal and identify the originating dependency.", "Protect the data path: pause aggressive retries and reduce connection pressure.", "Restore database pool capacity; verify acquire wait and replica health.", "Re-enable dependent traffic gradually, then watch error rate and p95 latency."]
    : ["<strong>Stabilize the database:</strong> cap retry traffic and pause non-critical workers to stop pool churn.", "<strong>Restore capacity:</strong> drain leaked sessions, recycle the affected pool, and verify connection headroom.", "<strong>Recover dependencies:</strong> clear payment backlog, then re-enable auth and notification traffic in stages.", "<strong>Validate recovery:</strong> confirm gateway errors return to baseline before closing the incident."];
  $("#recovery-list").innerHTML = items.map((text) => `<li><span>${text}</span></li>`).join("");
}
function renderLogs() {
  const logs = state.stage ? state.logs : baselineLogs.map((entry, index) => ({ ...entry, time: new Date(Date.now() - (3 - index) * 76000) }));
  $("#log-count").textContent = `${logs.length} entr${logs.length === 1 ? "y" : "ies"}`;
  $("#log-window").innerHTML = [...logs].reverse().map((entry) => {
    const levelClass = entry.level === "WARN" ? "warn" : entry.level === "ERROR" || entry.level === "CRIT" ? "error" : "";
    return `<div class="log-line"><time class="log-time">${fmtTime(entry.time)}</time><span class="log-level ${levelClass}">${entry.level}</span><span class="log-message">${entry.msg}</span></div>`;
  }).join("");
}
function renderTimeline() {
  const entries = state.eventTimes.length ? state.eventTimes : [{ time: new Date(Date.now() - 90000), title: "Demo environment ready", detail: "Sample telemetry loaded; no live monitoring connections.", tone: "" }];
  $("#timeline").innerHTML = [...entries].reverse().map((item) => `<div class="timeline-item ${item.tone || ""}"><time class="timeline-time">${fmtTime(item.time)}</time><i class="timeline-pin"></i><div class="timeline-text"><strong>${item.title}</strong><br>${item.detail}</div></div>`).join("");
  $("#timeline-state").textContent = state.stage ? state.simulationComplete ? "SIMULATION COMPLETE" : "ACTIVE SIMULATION" : "READY";
}
function render() {
  renderServices();
  renderSummary();
  renderCause();
  renderRecovery();
  renderLogs();
  renderTimeline();
  $("#incident-banner").classList.toggle("active", state.stage > 0);
  $("#banner-title").textContent = state.stage ? `INCIDENT SIM-${state.startedAt ? state.startedAt.getTime().toString().slice(-5) : "00000"}` : "";
  $("#banner-subtitle").textContent = state.stage ? `· ${rootSteps[state.stage - 1].subtitle}` : "";
  $("#banner-time").textContent = state.startedAt ? `STARTED ${fmtTime(state.startedAt)}` : "";
  $("#simulate").disabled = state.stage > 0;
}
function addLog(level, msg) {
  state.logs.push({ level, msg, time: new Date() });
}
function addTimeline(title, detail, tone = "") {
  state.eventTimes.push({ time: new Date(), title, detail, tone });
}
function startSimulation() {
  if (state.stage) return;
  state.startedAt = new Date();
  state.simulationComplete = false;
  state.eventTimes = [];
  state.logs = [];
  addTimeline("Simulation triggered", "A controlled database pool exhaustion scenario has started.", "warn");
  addLog("INFO", "simulator: injecting connection leak into db-primary pool · no external systems affected");
  advanceSimulation();
  state.timer = window.setInterval(advanceSimulation, 3200);
}
function advanceSimulation() {
  const step = rootSteps[state.stage];
  if (!step) {
    window.clearInterval(state.timer);
    state.timer = null;
    state.simulationComplete = true;
    addTimeline("Cascade stabilized for review", "Failure progression paused. Use the recovery playbook or reset to restore baseline.", "alert");
    render();
    return;
  }
  state.stage += 1;
  addLog(...step.log);
  const [title, detail, tone = "alert"] = step.timeline;
  addTimeline(title, detail, tone);
  render();
}
function resetSimulation() {
  if (state.timer) window.clearInterval(state.timer);
  state.stage = 0;
  state.startedAt = null;
  state.eventTimes = [];
  state.logs = [];
  state.timer = null;
  state.simulationComplete = false;
  render();
}
function createReport() {
  const at = stamp();
  const lines = services.map(({ id, name }) => {
    const data = serviceState(id);
    return `  ${name.padEnd(24)} ${statusLabel(data.status).padEnd(9)} ${String(data.latency).padStart(4)} ms latency   ${data.errors.toFixed(2)}% errors`;
  });
  const timeline = state.eventTimes.length
    ? state.eventTimes.map((event) => `  ${fmtTime(event.time)}  ${event.title} — ${event.detail}`).join("\n")
    : "  No incident events. Sample services remain nominal.";
  return [
    "CASCADEGUARD AI — INCIDENT REPORT",
    `Generated: ${at}`,
    "Mode: Browser-local educational simulation (not live monitoring or real AI)",
    "",
    state.stage ? `Incident: SIM-${state.startedAt?.getTime().toString().slice(-5) || "00000"} — ${state.simulationComplete ? "progression complete" : "in progress"}` : "Incident: No active incident",
    state.stage ? "Root cause: Simulated database connection pool exhaustion following a connection leak." : "Root cause: None detected in baseline sample data.",
    state.stage ? "Impact: Increasing database acquire waits cascade into payment, auth, notification, and gateway request paths." : "Impact: No service impact.",
    "",
    "SERVICE SNAPSHOT",
    ...lines,
    "",
    "TIMELINE",
    timeline,
    "",
    "RECOMMENDED RESPONSE",
    "1. Cap retries and pause non-critical workers to reduce database pool pressure.",
    "2. Recycle leaked sessions; verify pool headroom and replica health.",
    "3. Clear payment backlog and restore dependent traffic in controlled stages.",
    "4. Confirm gateway errors and latency return to baseline before closing.",
    "",
    "Educational simulation using sample data; not a production monitoring system.",
  ].join("\n");
}
let toastTimeout;
function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(toastTimeout);
  toastTimeout = window.setTimeout(() => toast.classList.remove("show"), 2400);
}
function closeReport() {
  $("#report-modal").classList.remove("open");
  $("#report").focus();
}

$("#simulate").addEventListener("click", startSimulation);
$("#reset").addEventListener("click", resetSimulation);
$("#report").addEventListener("click", () => {
  $("#report-text").textContent = createReport();
  $("#report-modal").classList.add("open");
  $("#close-report").focus();
});
$("#close-report").addEventListener("click", closeReport);
$("#report-modal").addEventListener("click", (event) => {
  if (event.target === $("#report-modal")) closeReport();
});
$("#copy-report").addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText($("#report-text").textContent);
    showToast("Incident report copied to clipboard");
  } catch {
    const range = document.createRange();
    range.selectNodeContents($("#report-text"));
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
    showToast("Select the report text and copy");
  }
});
$("#download-report").addEventListener("click", () => {
  const blob = new Blob([$("#report-text").textContent], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `cascadeguard-incident-${new Date().toISOString().slice(0, 10)}.txt`;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  showToast("Incident report downloaded");
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && $("#report-modal").classList.contains("open")) closeReport();
});
function updateClock() {
  $("#clock").textContent = `${new Intl.DateTimeFormat(undefined, { weekday: "short", month: "short", day: "2-digit" }).format(new Date())} · ${fmtTime()}`;
}
updateClock();
window.setInterval(updateClock, 1000);
render();
