# CascadeGuard AI

A client-side incident-response dashboard demo. All service metrics, dependency changes, logs, timelines, and report content are generated locally in the browser; it does not connect to live systems or use AI services.

## Run locally

From the workspace root, start the app with the existing Vite workflow:

```sh
pnpm --filter @workspace/cascadeguard-ai run dev
```
